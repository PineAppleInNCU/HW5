package Calculator;
import java.awt.Font;
import java.io.IOException;
import javax.swing.*;



public class main {
	
	 
	
	public static void main(String[] args) throws IOException {
		win frame = new win();//�s�X����
		
		
	}
	
}
